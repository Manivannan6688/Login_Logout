<?php

Class Login_Database extends CI_Model {

// Insert registration data in database
public function registration_insert($data) {

// Query to check whether username already exist or not
//$condition = "user_name =" . "'" . $data['user_name'] . "'";
//$email_condition = "user_email =" . "'" . $data['user_email'] . "'";
	$condition = $data['user_email'];
	//$email_condition = $data['user_email'];

$this->db->select('*');
$this->db->from('user_login');
$this->db->where('user_email',$condition);
//$this->db->or_where('user_email',$email_condition);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 0) {

// Query to insert data in database
$this->db->insert('user_login', $data);
if ($this->db->affected_rows() > 0) {
return true;
}
} else {
return false;
}
}

// Insert Product  in database
public function product_insert($data) {

$this->db->insert('user_product', $data);
// Query to check whether username already exist or not
//$condition = "user_name =" . "'" . $data['user_name'] . "'";
//$email_condition = "user_email =" . "'" . $data['user_email'] . "'";
  /* $condition = $data['user_email'];
   //$email_condition = $data['user_email'];

$this->db->select('*');
$this->db->from('user_login');
$this->db->where('user_email',$condition);
//$this->db->or_where('user_email',$email_condition);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 0) {

// Query to insert data in database
$this->db->insert('user_login', $data);
if ($this->db->affected_rows() > 0) {
return true;
}
} else {
return false;
}*/
}

// Insert registration data in database
/*public function registration_insert_email($data) {

// Query to check whether username already exist or not
//$condition = "user_name =" . "'" . $data['user_name'] . "'";
//$email_condition = "user_email =" . "'" . $data['user_email'] . "'";
	//$condition = $data['user_name'];
	$email_condition = $data['user_email'];

$this->db->select('*');
$this->db->from('user_login');
//$this->db->where('user_name',$condition);
$this->db->or_where('user_email',$email_condition);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 0) {

// Query to insert data in database
$this->db->insert('user_login', $data);
if ($this->db->affected_rows() > 0) {
return true;
}
} else {
return false;
}
}*/
//update data
public function update($data,$old_roll_no) { 
   $condition = $data['user_email'];
   //$email_condition = $data['user_email'];
//$email= 'manikkr6688@gmai.com';
$this->db->select('*');
$this->db->from('user_login');
$this->db->where('user_email',$condition);
$this->db->where('id !=',$old_roll_no);
//$this->db->or_where('user_email',$email_condition);
//$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows()==0) {


         $this->db->set($data); 
         $this->db->where("id", $old_roll_no); 
         $this->db->update("user_login", $data); 
         if ($this->db->affected_rows() > 0) {
return true;
}
}else {
return false;
}
      } 
//delete data

      public function delete($roll_no) { 
         if ($this->db->delete("user_login", "id = ".$roll_no)) { 
            return true; 
         } 
      }
// Read data using username and password
public function login($data) {

$condition = "user_name =" . "'" . $data['username'] . "' AND " . "user_password =" . "'" . $data['password'] . "'";
$this->db->select('*');
$this->db->from('user_login');
$this->db->where($condition);
$this->db->limit(1);
$query = $this->db->get();

if ($query->num_rows() == 1) {
return true;
} else {
return false;
}
}

// Read data from database to show data in admin page
public function read_user_information($username) {

$condition = "user_name =" . "'" . $username . "'";
$this->db->select('*');
$this->db->from('user_login');
$this->db->where($condition);
$this->db->limit(1);
$query = $this->db->get();

if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}
}

//upadate _product
public function update_product($data,$old_roll_no) { 
  /* $condition = $data['user_email'];
   //$email_condition = $data['user_email'];
//$email= 'manikkr6688@gmai.com';
$this->db->select('*');
$this->db->from('user_product');
$this->db->where('user_email',$condition);
$this->db->where('id !=',$old_roll_no);
//$this->db->or_where('user_email',$email_condition);
//$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows()==0) {


         $this->db->set($data); 
         $this->db->where("id", $old_roll_no); 
         $this->db->update("user_login", $data); 
         if ($this->db->affected_rows() > 0) {
return true;
}
}else {
return false;
}*/

         $this->db->set($data); 
         $this->db->where("id", $old_roll_no); 
         $this->db->update("user_product", $data); 

      } 

//product_delete_data
       public function delete_product($roll_no) { 
         if ($this->db->delete("user_product", "id = ".$roll_no)) { 
            return true; 
         } 
      }

}

?>
