<html>
<?php
if (isset($this->session->userdata['logged_in'])) {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);
$id = ($this->session->userdata['logged_in']['id']);
} else {
header("location: login");
}
?>
<head>
<title>Admin Page</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/style.css">
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'>
</head>
<body>
<div id="profile">
<?php
echo "Hello <b id='welcome'><i>" . $username . "</i> !</b>";
echo "<br/>";
echo "<br/>";
echo "Welcome to Admin Page";
echo "<br/>";
echo "<br/>";
echo "Your Username is " . $username;
echo "<br/>";
echo "Your Email is " . $email;
echo "<br/>";
echo "Your login_id is " . $id;
echo "<br/>";
?>
<!--<b id="logout"><a href="logout">Logout</a></b>-->
<b id="logout"><a href="http://localhost/login/index.php/User_Authentication/logout">Logout</a></b>
<!--<b id="logout"><a href="">Logout</a></b>-->
</div>
<br/>
</body>
</html>
<html>

<head>
<title>Registration Form</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/style.css">
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro|Open+Sans+Condensed:300|Raleway' rel='stylesheet' type='text/css'>
</head>
<body>
<div id="main">
<div id="login">
<h2>ADD Product</h2>
<hr/>
<?php
echo "<div class='error_msg'>";
echo validation_errors();
echo "</div>";
echo form_open('User_Authentication/new_user_product');
/*echo "<input type='text' name='name' value= '<?php echo $id; ?>' />";*/
echo "<input type='hidden' name='user_id' value= '$id' />";

echo form_label('Product name : ');
echo"<br/>";
echo form_input('product_name');
echo "<div class='error_msg'>";
if (isset($message_display)) {
echo $message_display;
}
echo "</div>";
echo"<br/>";
echo form_label('Price : ');
echo"<br/>";
$data = array(
'type' => 'text',
'name' => 'price'
);
echo form_input($data);
echo "<div class='error_msg'>";
if (isset($email_message_display)) {
echo $email_message_display;
}
echo "</div>";
echo"<br/>";
echo"<br/>";

echo form_label('Quantity : ');
echo"<br/>";
echo form_input('quantity');
echo "<div class='error_msg'>";
if (isset($message_display)) {
echo $message_display;
}
echo "</div>";
echo"<br/>";

echo form_submit('submit', 'Save');
echo form_close();
?>
<a href="<?php echo base_url() ?> ">For Login Click Here</a>
</div>
</div>
</body>
</html>


<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br>

<?php 
$DB2 = $this->load->database('default', TRUE);
$DB2->select ("*");
$DB2->from('user_product');
$DB2->where('user_id',$id);
//$DB2->where('earnings.deleted','0');
//$DB2 ->where('earnings.title','Basic Salary');
//$DB2 ->or_where('earnings.title','BasicSalary');
$query=$DB2->get();
$records=$query->result();


 ?>

<html lang = "en">
<table border = "1"> 
         <?php 
            $i = 1; 
            echo "<tr>"; 
            echo "<td>id</td>"; 
            echo "<td>product_id</td>"; 
            echo "<td>product_name</td>"; 
            echo "<td>quantity</td>"; 
            echo "<td>price</td>"; 
            echo "<td>Edit</td>"; 
            echo "<td>Delete</td>"; 
            echo "<tr>"; 
            
            foreach($records as $r) { 
               echo "<tr>"; 
               echo "<td>".$i++."</td>"; 
               echo "<td>".$r->id."</td>"; 
               echo "<td>".$r->product_name."</td>"; 
               echo "<td>".$r->quantity."</td>";
               echo "<td>".$r->price."</td>"; 
               echo "<td><a href = '".base_url()."index.php/User_Authentication/update_product_view/"
                  .$r->id."'>Edit</a></td>"; 
               echo "<td><a href = '".base_url()."index.php/User_Authentication/delete_product/"
                  .$r->id."'>Delete</a></td>"; 
               echo "<tr>"; 
            } 
         ?>
      </table>
      </html>
