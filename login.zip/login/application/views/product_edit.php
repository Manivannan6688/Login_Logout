<!DOCTYPE html> 
<html lang = "en">
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Students Example</title> 
      <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>asset/style.css">

   </head> 
   
   <body> 
      
      
         <?php 
            echo form_open('User_Authentication/update_product'); 
            echo form_hidden('old_roll_no',$old_roll_no); 
            echo form_label('Roll No.'); 
            echo form_input(array('id'=>'product_name',
               'name'=>'product_name','value'=>$records[0]->product_name))
             
               ."<br>"."<br>";
            echo form_label('quantity'); 
            echo form_input(array('id'=>'quantity','name'=>'quantity',
               'value'=>$records[0]->quantity)) ."<br>"."<br>"; 


// Insert registration data in database
//public function registration_insert($data) {

// Query to check whether username already exist or not
//$condition = "user_name =" . "'" . $data['user_name'] . "'";
//$email_condition = "user_email =" . "'" . $data['user_email'] . "'";
  // $email_condition = $email_data['user_email'];
   //$email_condition = $data['user_email'];

/*$this->db->select('*');
$this->db->from('user_login');
$this->db->where('user_email');//,$condition);
//$this->db->or_where('user_email',$email_condition);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 0) {

// Query to insert data in database
//$this->db->insert('user_login', $data);
if ($this->db->affected_rows() > 0) {
return true;
}
} else {
return false;
}*/

            
             echo form_label('price'); 
           echo form_input(array('id'=>'price','name'=>'price',
               'value'=>$records[0]->price)) ."<br>"."<br>"; 
            

          echo form_submit(array('id'=>'submit','value'=>'Edit')); 
            echo form_close();
         ?> 
         
     
   </body>
   
</html>